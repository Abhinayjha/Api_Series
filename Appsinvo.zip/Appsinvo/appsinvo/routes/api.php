<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// Serial No. 1
Route::post('/createUser', [UserController::class, 'createUser']);

// Serial No. 2
Route::put('/createData', [UserController::class, 'changeStatus']);

// Serial No. 3
Route::post('/getDistance', [UserController::class, 'getDistance']);

// Serial No. 4
Route::post('/userListing', [UserController::class, 'UserListing']);

Route::group(['middleware' => 'api'], function ($routes) {
});
