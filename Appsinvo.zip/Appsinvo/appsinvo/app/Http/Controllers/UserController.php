<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\listing;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{

    // Serial No. 1 Backend logic start
    public function createUser(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|string|email|max:100|unique:users',
            'password' => 'required|string|min:6',
            'address' => 'required',
            'latitude' => 'required',
            'longitude' => 'required',
            'status' => 'required',
        ]);

        if ($validate->fails()) {
            return response()->json($validate->errors());
        }

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'address' => $request->address,
            'latitude' => $request->latitude,
            'longitude' => $request->longitude,
            'status' => $request->status,
        ]);

        $token = $user->createToken('MyApp')->plainTextToken;

        return response()->json([
            'status_code' => "200",
            'message' => 'User Data Inserted Successfully!',
            'data' => $user,
            'token' => $token,
        ]);
    }
    // Serial No. 1 Backend logic end


    // Serial No. 2 Backend logic start
    public function seeData()
    {
        User::query()->update([
            'status' => DB::raw('IF(status = 1, 0, 1)')
        ]);

        return response()->json(['message' => 'User statuses have been updated successfully.'], 200);
    }
    // Serial No. 2 Backend logic end


    // Serial No. 3 Backend logic start
    public function getDistance(Request $request)
    {
        $lat1 = deg2rad($request->lat1);
        $lat2 = deg2rad($request->lat2);
        $long1 = deg2rad($request->long1);
        $long2 = deg2rad($request->long2);

        $dlong = $long2 - $long1;
        $dlati = $lat2 - $lat1;

        $val = pow(sin($dlati / 2), 2) + cos($lat1) * cos($lat2) * pow(sin($dlong / 2), 2);

        $res = 2 * asin(sqrt($val));

        if ($res) {
            return  response()->json([
                'status_code' => '200',
                'message' => 'Distance between two point of latitude and longitude.',
                'distance' => $res,
            ]);
        }

        return response()->json('message', 'All the parameter are not fullfilled!');
    }
    // Serial No. 3 Backend logic end


    // Serial No. 4 Backend logic start
    public function UserListing(Request $request)
    {

        $validate = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email|string|max:100|unique:user_listing',
            'password' => 'required|string|min:6',
            'status' => 'required',
            'day' => 'required',
            'address' => 'required',
        ]);

        if ($validate->fails()) {
            return response()->json($validate->errors());
        }

        $userlisting = listing::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'status' => $request->status,
            'day' => $request->day,
            'address' => $request->address,
        ]);

        $token = $userlisting->createToken('MyApp')->plainTextToken;

        return response()->json([
            'status_code' => "200",
            'message' => "User Listing is created Successfully!",
            'data' => $userlisting,
            'token' => $token,
        ]);
    }
    // Serial No. 4 Backend logic end
}
